# Claustromania - Sistema de Agendamento de Escape Rooms
Projeto de Desenvolvimento de Sistema WEB - Programação WEB II

- Descrição
  O Claustromania é uma aplicação web para agendamento e gerenciamento de reservas em salas de escape room.

- Alunos
João Pedro Gundim Guimarães
Théo Teodoro Novais

- Orientação
João Eujacio Teixeira Junior
